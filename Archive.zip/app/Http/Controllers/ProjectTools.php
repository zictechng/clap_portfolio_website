<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ProjectTools extends Controller
{
    protected $table="project_tools";
}

<div class="d-flex justify-content-center mt-30">
    <p class="copyright">Copyright © 2024 All Rights Reserved by jobpath</p>
</div>

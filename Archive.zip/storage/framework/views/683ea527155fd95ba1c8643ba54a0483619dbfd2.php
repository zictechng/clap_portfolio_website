<header class="rts__section rts__header relative__header div_header">
    <div class="container-none">
        <div class="rts__menu__background">
            <div class="row">
                <div class="d-flex align-items-center justify-content-between">
                    <div class="rts__logo">
                        <a href="/">
                            <img class="logo__image" src="<?php echo e(asset('assets/img/logo/logo_white.png')); ?>" width="160" height="40"
                                alt="logo">
                        </a>
                    </div>
                    <?php echo $__env->make('user.navBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>

        </div>
    </div>
    <hr class="new1">
</header>
<?php /**PATH /home/zictevvd/clapportfolio.zictech-ng.com/resources/views/user/mainHeader.blade.php ENDPATH**/ ?>
<div class="blank_banner">

</div>
<div class="main_section_for_profile_view">
    <div class="container">
        <div class="row">
            <div class="col-lg-4">
                <div class="profile_card_areas">
                    <div class="profile_card">
                        <div class="profile_image">

                            <?php if(!empty($user_details?->profile_url) && file_exists(public_path('profile_images/' . $user_details?->profile_url))): ?>
                        <img class="rounded" src="<?php echo e(asset('profile_images/' . $user_details?->profile_url)); ?>" alt="<?php echo e($user_details?->name); ?>" style="width: 50px; height: 50px;">
                        <?php else: ?>
                            <i class="bi bi-person-circle" style="font-size: 4rem; color: #7d8087;" width="50px"></i>
                        <?php endif; ?>
                        </div>
                        <h4><?php echo e($user_details->name.' '.$user_details->lname); ?></h4>
                        <div class="social_link">
                            <ul>
                                <li>
                                    <a href="<?php echo e($social_link?->social_linkedin); ?>" target="_blank" rel="noopener noreferrer">
                                        <span>
                                            <?php if($social_link?->social_linkedin): ?>
                                                <img src="<?php echo e(asset('assets/image/linkdin.png')); ?>" alt="">
                                            <?php endif; ?>
                                        </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo e($social_link?->social_github); ?>" target="_blank" rel="noopener noreferrer">
                                        <span>
                                            <?php if($social_link?->social_github): ?>
                                            <img src="<?php echo e(asset('assets/image/github.png')); ?>" alt="" srcset="">
                                            <?php endif; ?>
                                        </span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="profile_faq">
                        <div class="faq_item">
                            <div class="faq_heading">
                                <h4>About </h4>
                                <span>
                                    <i class="fa-solid fa-angle-down"></i>
                                </span>
                            </div>
                            <div class="faq_content">
                                <p>
                                    <?php echo e($user_details->user_biography? :'No biography available'); ?>

                                </p>
                            </div>
                        </div>
                        <div class="faq_item">
                            <div class="faq_heading">
                                <h4>Certifications </h4>
                                <span>
                                    <i class="fa-solid fa-angle-down"></i>
                                </span>
                            </div>
                            <div class="faq_content">
                                <p>
                                    No certifications available
                                </p>

                            </div>
                        </div>
                        <div class="faq_item">
                            <div class="faq_heading">
                                <h4>Education </h4>
                                <span>
                                    <i class="fa-solid fa-angle-down"></i>
                                </span>
                            </div>
                            <div class="faq_content">
                                <?php $__empty_1 = true; $__currentLoopData = $education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $educations): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <p>
                                    <span style="font-weight: 600;"><?php echo e($educations->degree_name); ?></span>
                                    <br/>
                                    <?php echo e($educations->institution_name); ?>

                                    <br/>
                                    <span style="font-size: 0.775rem;">(<?php echo e(\Carbon\Carbon::parse($educations->start_date)->format('d M, Y')); ?> - <?php echo e(\Carbon\Carbon::parse($educations->end_date)->format('d M, Y')); ?>)</span>
                                </p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p>
                                    No education available
                                </p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="faq_item">
                            <div class="faq_heading">
                                <h4>Work Experience </h4>
                                <span>
                                    <i class="fa-solid fa-angle-down"></i>
                                </span>
                            </div>
                            <div class="faq_content">
                                <?php $__empty_1 = true; $__currentLoopData = $work_experience; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work_experiences): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <p>
                                    <span style="font-weight: 600;"><?php echo e($work_experiences->job_title); ?></span>
                                    <br/>
                                    <?php echo e($work_experiences->job_organization); ?>

                                    <br/>
                                        <span style="font-size: 0.775rem;">(<?php echo e(\Carbon\Carbon::parse($work_experiences->job_start_date)->format('d M, Y')); ?> -
                                        <?php if($work_experiences->job_end_date): ?>
                                        <?php echo e(\Carbon\Carbon::parse($work_experiences->job_end_date)->format('d M, Y')); ?>

                                    <?php else: ?>
                                        Till date
                                    <?php endif; ?>
                                    </span>
                                    <br/>
                                </p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p>
                                    No work experience available
                                </p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="faq_item">
                            <div class="faq_heading">
                                <h4>Additional links </h4>
                                <span>
                                    <i class="fa-solid fa-angle-down"></i>
                                </span>
                            </div>
                            <div class="faq_content">
                                <p>
                                    <?php echo e($user_details->web_link? :'No additional link available'); ?>

                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-8">
                <div class="profile_column_wrapers_sections">
                    <div class="filter_btns_section mb-4 d-flex align-items-center gap-3">
                        <button class="active_btns list_buttons">Projects</button>
                        <button class="grid_buttons">Top Performing</button>
                    </div>
                    <!----------------------------------------post section---------------------------------->
                    <?php if($projects->count()): ?>
                    <div class="project_wrapers box_list">
                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="project_card_item d-flex gap-3">
                            <div class="project_image">
                                <a href="<?php echo e(route('project.details', ['slug' => $project_data->project_slug])); ?>" class="blog__img">
                                    <?php if(!empty($project_data->project_image) && file_exists(public_path('project_images/' . $project_data->project_image))): ?>
                                    <img src="<?php echo e(asset('project_images/' . $project_data->project_image)); ?>" alt="<?php echo e($project_data->project_title); ?>" style="width: 185px; height: 150px; border-radius: 8px">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('dashboardAsset/images/profile_pics.png')); ?>" alt="Project Default Image" style="width: 185px; height: 150px;">
                                <?php endif; ?>
                                </a>
                            </div>
                            <div class="project_content">
                                <h4><a href="<?php echo e(route('project.details', ['slug' => $project_data->project_slug])); ?>" style="color: black"><?php echo e($project_data->project_title); ?></a></h4>
                                <p>
                                    <?php echo e(Str::limit($project_data->project_description ?? 'Description', 150, '...')); ?>

                                </p>
                                <div class="project_author_tools">
                                    <div class="project_author_section d-flex align-items-center justify-content-space-between gap-3">
                                        <div class="activity_ber d-flex align-items-center gap-2">
                                            <a href="#">
                                                <span>
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M3.80638 6.20757C4.70651 5.30771 5.92719 4.8022 7.19998 4.8022C8.47276 4.8022 9.69344 5.30771 10.5936 6.20757L12 7.61277L13.4064 6.20757C13.8492 5.74912 14.3788 5.38345 14.9644 5.13188C15.5501 4.88032 16.1799 4.74791 16.8172 4.74237C17.4546 4.73683 18.0866 4.85828 18.6766 5.09963C19.2665 5.34098 19.8024 5.69739 20.2531 6.14807C20.7038 6.59876 21.0602 7.13469 21.3015 7.72459C21.5429 8.31449 21.6643 8.94656 21.6588 9.5839C21.6532 10.2212 21.5208 10.8511 21.2693 11.4367C21.0177 12.0223 20.652 12.552 20.1936 12.9948L12 21.1896L3.80638 12.9948C2.90651 12.0946 2.401 10.874 2.401 9.60117C2.401 8.32838 2.90651 7.1077 3.80638 6.20757V6.20757Z" stroke="#202020" stroke-width="2" stroke-linejoin="round"/>
                                                      </svg>
                                                      <?php echo e(format_count($project_data->like_count)); ?>

                                                </span>
                                            </a>
                                            <a href="#">
                                                <span>
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                        <path d="M20.2338 15.6356C20.7253 14.5238 20.9983 13.2938 20.9983 12C20.9983 7.02944 16.9692 3 11.9991 3C7.02906 3 3 7.02944 3 12C3 16.9706 7.02906 21 11.9991 21C13.5993 21 15.1019 20.5823 16.4039 19.85L21 20.9991L20.2338 15.6356Z" stroke="#202020" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                                      </svg>
                                                      <?php echo e(format_count($project_data->comment_count)); ?>

                                                </span>
                                            </a>
                                        </div>
                                        <div class="user_profile d-flex align-items-center gap-3">
                                            <div class="user_image">
                                                <?php if(!empty($project_data?->user->profile_url) && file_exists(public_path('profile_images/' . $project_data?->user->profile_url))): ?>
                                                    <img class="rounded" src="<?php echo e(asset('profile_images/' . $project_data?->user->profile_url)); ?>" alt="<?php echo e($project_data?->user->name); ?>" style="width: 28px; height: 28px;">
                                                    <?php else: ?>
                                                        <i class="bi bi-person-circle" style="font-size: 2rem; color: #7d8087;" width="30px"></i>
                                                    <?php endif; ?>
                                            </div>
                                            <div class="user_details">
                                                <h4><?php echo e(Str::limit($project_data->user->name .' '. $project_data->user->lname ?? 'Unknown', 20, '...')); ?></h4>
                                            </div>
                                            <div class="user_check">
                                                <img src="<?php echo e(asset('assets/image/check.png')); ?>" alt="" srcset="">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                        <div class="mt-3">

                        </div>
                    <?php else: ?>
                    <p class="text-center text-gray-500">No project found at the moment.</p>
                    <?php endif; ?>
                    <!------------------------------------Grid item ------------------------------------>
                    <div class="project_wrapers box_grid" style="display: none;">
                            <div class="row">
                                <div class="col-lg-6 col-6">
                                    <div class="project_card_item d-flex gap-3">
                                        <div class="project_image">
                                            <a href="<?php echo e(route('project.details', ['slug' => $project_data->project_slug])); ?>" class="blog__img">
                                                <?php if(!empty($project_data->project_image) && file_exists(public_path('project_images/' . $project_data->project_image))): ?>
                                                <img src="<?php echo e(asset('project_images/' . $project_data->project_image)); ?>" alt="<?php echo e($project_data->project_title); ?>" style="width: 185px; height: 150px";>
                                            <?php else: ?>
                                                <img src="<?php echo e(asset('dashboardAsset/images/profile_pics.png')); ?>" alt="Project Default Image" style="width: 185px; height: 150px;">
                                            <?php endif; ?>
                                            </a>
                                        </div>
                                        <div class="project_content">
                                            <h4><a href="<?php echo e(route('project.details', ['slug' => $project_data->project_slug])); ?>" style="color: black"><?php echo e($project_data->project_title); ?></a></h4>
                                            <p>
                                                <?php echo e(Str::limit($project_data->project_description ?? 'Description', 150, '...')); ?>

                                            </p>
                                            <div class="project_author_tools">
                                                <div class="project_author_section d-flex align-items-center justify-content-space-between gap-3">
                                                    <div class="activity_ber d-flex align-items-center gap-2">
                                                        <a href="">
                                                            <span>
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M3.80638 6.20757C4.70651 5.30771 5.92719 4.8022 7.19998 4.8022C8.47276 4.8022 9.69344 5.30771 10.5936 6.20757L12 7.61277L13.4064 6.20757C13.8492 5.74912 14.3788 5.38345 14.9644 5.13188C15.5501 4.88032 16.1799 4.74791 16.8172 4.74237C17.4546 4.73683 18.0866 4.85828 18.6766 5.09963C19.2665 5.34098 19.8024 5.69739 20.2531 6.14807C20.7038 6.59876 21.0602 7.13469 21.3015 7.72459C21.5429 8.31449 21.6643 8.94656 21.6588 9.5839C21.6532 10.2212 21.5208 10.8511 21.2693 11.4367C21.0177 12.0223 20.652 12.552 20.1936 12.9948L12 21.1896L3.80638 12.9948C2.90651 12.0946 2.401 10.874 2.401 9.60117C2.401 8.32838 2.90651 7.1077 3.80638 6.20757V6.20757Z" stroke="#202020" stroke-width="2" stroke-linejoin="round"/>
                                                                  </svg>
                                                                  <?php echo e(format_count($project_data->like_count)); ?>

                                                            </span>
                                                        </a>
                                                        <a href="">
                                                            <span>
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                                    <path d="M20.2338 15.6356C20.7253 14.5238 20.9983 13.2938 20.9983 12C20.9983 7.02944 16.9692 3 11.9991 3C7.02906 3 3 7.02944 3 12C3 16.9706 7.02906 21 11.9991 21C13.5993 21 15.1019 20.5823 16.4039 19.85L21 20.9991L20.2338 15.6356Z" stroke="#202020" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                                                  </svg>
                                                                  <?php echo e(format_count($project_data->comment_count)); ?>

                                                            </span>
                                                        </a>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>

                        </div>
                    <!-------------------------------------post lernmore section-------------------------------->
                    <div class="lern_more_areas">
                        <a href="">
                            <?php echo e($projects->links()); ?>

                        </a>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<script>
        document.addEventListener('DOMContentLoaded', () => {
    const listButton = document.querySelector('.list_buttons');
    const gridButton = document.querySelector('.grid_buttons');
    const boxList = document.querySelector('.box_list');
    const boxGrid = document.querySelector('.box_grid');

    // Function to switch to List view
    listButton.addEventListener('click', () => {
        listButton.classList.add('active_btns');
        gridButton.classList.remove('active_btns');
        boxList.style.display = 'block';
        boxGrid.style.display = 'none';
    });

    // Function to switch to Grid view
    gridButton.addEventListener('click', () => {
        gridButton.classList.add('active_btns');
        listButton.classList.remove('active_btns');
        boxGrid.style.display = 'block';
        boxList.style.display = 'none';
    });
});

</script>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/clapWebsiteBackup/resources/views/livewire/profile-component.blade.php ENDPATH**/ ?>
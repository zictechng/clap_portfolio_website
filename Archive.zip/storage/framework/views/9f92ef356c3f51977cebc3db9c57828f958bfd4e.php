

<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="/user/dashboard">
        <div class="sidebar-brand-icon mt-3">
            <img src="<?php echo e(asset('assets/img/logo/logo_white.png')); ?>" width="130" height="50" >
        </div>
        
    </a>

    <!-- Divider -->
    <br/>


    <!-- Nav Item - Dashboard -->
    <li class="nav-item active">
        <a class="nav-link" href="/user/dashboard">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span></a>
    </li>

    <!-- Divider -->
    <!-- <hr class="sidebar-divider"> -->

    <!-- Nav Item - Tables -->
    <li class="nav-item">
        <a class="nav-link" href="/user/profile">
            <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
            <span>Profile</span></a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="/user/portfolio">
            <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
            <span>Portfolio</span></a>
    </li>

    <!-- Divider -->
    <!-- <hr class="sidebar-divider"> -->

    <!-- Heading -->
    

    <!-- Divider -->
    <!-- Sidebar Toggler (Sidebar) -->
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>

    <!-- Sidebar Message -->
</ul>
<?php /**PATH /home/zictevvd/clapportfolio.zictech-ng.com/resources/views/userDash_template/dash_siderBar.blade.php ENDPATH**/ ?>
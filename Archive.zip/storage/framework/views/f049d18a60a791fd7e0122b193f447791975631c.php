


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="description" content="Your Ultimate Job HTML Template">
    <meta name="keywords" content="Job, Resume, Employer, Agency">
    <link rel="canonical" href="#">
    <meta name="robots" content="index, follow">
    <!-- for open graph social media -->
    <meta property="og:title" content="Your Ultimate Job HTML Template">
    <meta property="og:description" content="Your Ultimate Job HTML Template">
    <meta property="og:image" content="../../../www.example.com/image.html">
    <meta property="og:url" content="#https://html.themewant.com/jobpath/">
    <!-- for twitter sharing -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="Your Ultimate Job HTML Template">
    <meta name="twitter:description" content="Your Ultimate Job HTML Template">
    <!-- fabicon -->
    <link rel="shortcut-icon" href="<?php echo e(asset('assets/img/favicon-16x16.png')); ?>" type="image/x-icon">

    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@200..800&amp;display=swap"
        rel="stylesheet">
    <link rel="shortcut icon" href="<?php echo e(asset('assets/img/favicon-16x16.png')); ?>" type="image/x-icon">
    <title>Clap Academy - Project Seeker &amp; Job Seeker and employee</title>
    <!-- rt icons -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/fonts/icon/css/rt-icons.css')); ?>">
    <!-- fontawesome -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/fonts/fontawesome/fontawesome.min.css')); ?>">
    <!-- all plugin css -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/plugins.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <?php echo \Livewire\Livewire::styles(); ?>

</head>


<body class="is__home home__three">


    <style type="text/css">
        .rounded{
  border-radius:50% !important;
    }
    .main_page_background {
        background-color: #F9F9F9;
    }
    .item_page_background {
        background-color: #FFFFFF;
        border-radius:8px;
    }
    </style>
    <!-- header area -->
        <?php echo $__env->make('user.mainHeader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- banner area -->

    <!-- banner area end -->
     <!-- Main page comes here -->

        <?php echo e($slot); ?>



        <?php echo $__env->make('user.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!-- Mobile Side Menu -->
        <?php echo $__env->make('user.mobile_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- THEME PRELOADER START -->
    <div class="loader-wrapper">
        <div class="loader">
        </div>
        <div class="loader-section section-left"></div>
        <div class="loader-section section-right"></div>
    </div>
    <!-- THEME PRELOADER END -->

    <!-- Scroll to up Button -->
    <button type="button" class="rts__back__top" id="rts-back-to-top">
        <i class="fas fa-arrow-up"></i>
    </button>
    <!-- all plugin js -->
    <script src="<?php echo e(asset('assets/js/plugins.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>

    <?php echo \Livewire\Livewire::scripts(); ?>

</body>

</html>

<?php /**PATH /home/zictevvd/clapportfolio.zictech-ng.com/resources/views/layouts/guest.blade.php ENDPATH**/ ?>
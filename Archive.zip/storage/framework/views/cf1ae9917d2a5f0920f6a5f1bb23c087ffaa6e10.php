

<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\GuestLayout::class, []); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <!-- breadcrumb area -->
     <div class="mt-40"></div>
     
        <!-- breadcrumb area end -->

    <div class="candidate__passwordchange">

        <div class="change__password" style="margin-top: 100px;">
            <div class="password__change__form max-content similar__form form__padding mt-30">
                <h6 class="text-center fw-semibold mb-30">Login</h6>

                
                <div class="d-flex gap-4 flex-wrap justify-content-center mt-20 mb-20">
                    <div class="is__social google">
                        <button><img src="<?php echo e(asset('assets/img/icon/google-small.svg')); ?>" alt="">Login with Google</button>
                    </div>

                </div>
                <div class="d-block has__line text-center">
                    <p>Or</p>
                </div>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.validation-errors','data' => ['class' => 'mb-4']]); ?>
<?php $component->withName('jet-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                <form method="POST" action="<?php echo e(route('login')); ?>" class="d-flex flex-column gap-3">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="email" class="fw-medium text-dark mb-3">Your Email</label>
                        <div class="position-relative">
                            <input type="email" name="email" id="email" placeholder="Enter your email" autofocus>
                            <i class="fa-light fa-user icon"></i>

                        </div>
                    </div>
                    <div class="form-group">
                        <label for="password" class="fw-medium text-dark mb-3">Password</label>
                        <div class="position-relative">
                            <input type="password" name="password" id="password" placeholder="Enter your password" autocomplete="current-password">
                            <i class="fa-light fa-lock icon"></i>
                            <?php $__errorArgs = ['form.password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-red-600"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="d-flex flex-wrap justify-content-between align-items-center fw-medium">
                        <div class="form-check">
                            <input class="form-check-input" name="remember" type="checkbox" value="" id="flexCheckDefault">
                            <label class="form-check-label" for="flexCheckDefault">
                                Remember me
                            </label>
                        </div>
                        <a href="/forgot-password" class="forgot__password text-para">Forgot Password?</a>
                    </div>
                    <div class="form-group my-3">
                        <button class="rts__btn small__btn common__btn he-4 rounded-5 fill__btn" type="submit">Login</button>
                    </div>
                </form>

                <div class="d-flex gap-4 flex-wrap justify-content-center mt-20 mb-30"></div>
                <p style="font-size: 14px !important; color: #aaaaaa; text-align:center;">
                    By logging in, you agree to accept all Clap Academy's <a href="#">Terms of service</a> and <a href="#">Privacy Policy</a>.
                </p>
                <span class="d-block text-center fw-medium">Don`t have an account? <a href="<?php echo e(route('register')); ?>" class="text-primary">Sign Up</a>
                </span>
            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\clapacademy_profile_laravel\resources\views/auth/login.blade.php ENDPATH**/ ?>
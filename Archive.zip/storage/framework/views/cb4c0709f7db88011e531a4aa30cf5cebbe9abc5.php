<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; Clap Academy <?php echo e(now()->year); ?></span>
        </div>
    </div>
</footer>
<?php /**PATH /home/zictevvd/clapportfolio.zictech-ng.com/resources/views/userDash_template/dash_footer.blade.php ENDPATH**/ ?>